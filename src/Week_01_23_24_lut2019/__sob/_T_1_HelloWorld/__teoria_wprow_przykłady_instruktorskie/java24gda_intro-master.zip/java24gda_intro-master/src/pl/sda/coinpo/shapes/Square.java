package pl.sda.coinpo.shapes;

public class Square extends Rectangle {
    public Square(double widthAndHeight) {
        super("Square", widthAndHeight, widthAndHeight);
    }
}
