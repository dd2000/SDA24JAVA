package pl.sda.encapsulation.task;

public class OnlineShop {
    public static void main(String[] args) {
        // TODO
    }
}
