package pl.sda.generics;

public enum Gender {
    MALE,
    FEMALE,
    OTHER;
}
