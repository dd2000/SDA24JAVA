package pl.sda.abstra.shapes;

public abstract class Shape {
    public abstract void draw();
}