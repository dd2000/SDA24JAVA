package pl.sda.abstra.shapes;

public class Rectangle extends Shape {
    @Override
    public void draw() {
        System.out.println("DRAW: RECTANGLE");
    }
}
