package pl.sda.generics;

public class Car {}
