package pl.sda.coinpo.composition;

public enum EngineType {
    DIESEL,
    PETROL,
    HYBRID,
    ELECTRIC
}
