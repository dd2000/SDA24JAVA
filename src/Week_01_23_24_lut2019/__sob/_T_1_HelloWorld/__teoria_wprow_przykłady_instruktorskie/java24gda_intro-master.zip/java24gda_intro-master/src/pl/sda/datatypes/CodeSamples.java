package pl.sda.datatypes;

public class CodeSamples {
    public static void main(String[] args) {
        //deklaracja i incjalizacja danych
        int x;
        x = 100;

        int y = 8;
        double d = 5.6;

        char c = 'a';
        int symbol = c;
        System.out.println("symbol = " + symbol);
        System.out.println("c = " + c);

        String str = "Ala ma kota";

        boolean b = true;
        boolean b1 = false;

    }
}
